#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "include/display_standars.h"
#include "include/game.h"
#include "include/cards.h"
#include "include/players.h"
#include "include/server.h"
#include "include/client.h"

int main() {
	printMenu();
	
	exit(EXIT_SUCCESS);
}