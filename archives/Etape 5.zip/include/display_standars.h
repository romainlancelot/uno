#ifndef DEF_HEADER_DISPLAY_STANDARS
#define DEF_HEADER_DISPLAY_STANDARS


#define CLEAR_SCREEN printf("\e[1;1H\e[2J");
#define SEPARATEUR printf(" -------------------------------------------- \n\n");

#endif